﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Migrations;
using Pizzeria.Model;

namespace Pizzeria
{
    public class AppDbContext : DbContext
    {
       
        public DbSet<Pizza> Pizzas { get; set; }
        public DbSet<Bestelling> Bestelling { get; set; }
        public DbSet<Status> Status { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(
                "Server=localhost;Database=stonkspizza;User=root;Password=;",
                new MySqlServerVersion(new Version(10, 4, 32)) // Zorg ervoor dat deze versie overeenkomt met je MySQL-installatie
            );
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            

            // Configuratie voor Pizza-entiteit
            modelBuilder.Entity<Pizza>(entity =>
            {
                entity.ToTable("pizza"); // Koppel de entiteit aan de tabel 'pizza'
                entity.HasKey(p => p.Id); // Stel de primaire sleutel in

                entity.Property(p => p.Naam)
                      .IsRequired()
                      .HasMaxLength(255);

                entity.Property(p => p.Beschrijving)
                      .HasMaxLength(500);

                entity.Property(p => p.Prijs)
                      .HasColumnType("decimal(5,2)");

                entity.Property(p => p.Image)
                      .HasColumnType("longblob"); // Zorg ervoor dat dit overeenkomt met het datatype in je database
            });

            // Relatie tussen Bestelling en Status instellen
            modelBuilder.Entity<Bestelling>()
                .HasOne(b => b.Status)
                .WithMany()
                .HasForeignKey(b => b.status_id)
                .OnDelete(DeleteBehavior.Restrict);

            // Configuratie voor Bestelling-entiteit
            modelBuilder.Entity<Bestelling>(entity =>
            {
                entity.Property(b => b.CreatedAt).HasColumnName("created_at");
                entity.Property(b => b.UpdatedAt).HasColumnName("updated_at");
            });
        }
    }
}
