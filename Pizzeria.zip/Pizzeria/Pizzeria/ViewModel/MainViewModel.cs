﻿using Pizzeria.Helpers;
using Pizzeria.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Threading;



namespace Pizzeria.ViewModel
{
    public class MainViewModel : ObservableObject
    {
        #region Properties

        private string _currentTime;
        public string CurrentTime
        {
            get => _currentTime;
            set
            {
                _currentTime = value;
                OnPropertyChanged();
            }
        }

        private DispatcherTimer _timer;

        private object _currentView;
        public object CurrentView
        {
            get => _currentView;
            set
            {
                _currentView = value;
                OnPropertyChanged();
            }
        }

        public ICommand ShowContactPageCommand { get; }
        public ICommand ShowPizzaPageCommand { get; }

        #endregion

        #region Constructor

        public MainViewModel()
        {

            // Timer instellen om de tijd elke seconde bij te werken
            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            _timer.Tick += UpdateCurrentTime;
            _timer.Start();

            // Zet de huidige tijd bij de start
            UpdateCurrentTime(null, null);

            ShowContactPageCommand = new RelayCommand(ExecuteShowContactPage);
            ShowPizzaPageCommand = new RelayCommand(ExecuteShowPizzaPage);

            // Default View
            ExecuteShowContactPage();
        }

        #endregion

        private void UpdateCurrentTime(object sender, EventArgs e)
        {
            CurrentTime = DateTime.Now.ToString("HH:mm:ss");
        }

        #region Methods

        private void ExecuteShowContactPage(object obj = null)
        {
            CurrentView = new ContactPageViewModel();
        }

        private void ExecuteShowPizzaPage(object obj = null)
        {
            CurrentView = new PizzaViewModel();
        }

        #endregion
    }
}
