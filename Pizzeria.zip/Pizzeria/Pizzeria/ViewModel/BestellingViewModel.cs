﻿using Pizzeria.Helpers;
using Pizzeria.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;


namespace Pizzeria.ViewModel
{
    public class BestellingViewModel : ObservableObject
    {
        private readonly AppDbContext _context;

        public ObservableCollection<Bestelling> Bestellingen { get; set; }
        public ObservableCollection<Status> Statussen { get; set; }

        private Bestelling _selectedBestelling;
        public Bestelling SelectedBestelling
        {
            get => _selectedBestelling;
            set
            {
                _selectedBestelling = value;
                OnPropertyChanged();
            }
        }

        private Status _selectedStatus;
        public Status SelectedStatus
        {
            get => _selectedStatus;
            set
            {
                _selectedStatus = value;
                OnPropertyChanged();
            }
        }

        public ICommand UpdateStatusCommand { get; }

        public BestellingViewModel()
        {
            _context = new AppDbContext();

            // Laad bestellingen en statussen
            Bestellingen = new ObservableCollection<Bestelling>(
                _context.Bestelling.Include(b => b.Status).ToList()
            );
            Statussen = new ObservableCollection<Status>(_context.Status.ToList());

            // Command initialiseren
            UpdateStatusCommand = new RelayCommand(UpdateStatus);
        }

        private void UpdateStatus(object obj)
        {
            if (SelectedBestelling != null && SelectedStatus != null)
            {
                var bestelling = _context.Bestelling.FirstOrDefault(b => b.Id == SelectedBestelling.Id);
                if (bestelling != null)
                {
                    bestelling.status_id = SelectedStatus.id; // Update status
                    _context.SaveChanges();

                    // Refresh lijst
                    Bestellingen = new ObservableCollection<Bestelling>(
                        _context.Bestelling.Include(b => b.Status).ToList()
                    );
                }
            }
        }
    }
}
